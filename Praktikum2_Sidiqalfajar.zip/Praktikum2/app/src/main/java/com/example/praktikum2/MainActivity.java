package com.example.praktikum2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText bil1, bil2, operasi;
    Button hitung;
    TextView hasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bil1 = findViewById(R.id.editTextTextPersonName2);
        bil2 = findViewById(R.id.editTextTextPersonName);
        operasi = findViewById(R.id.editTextTextPersonName3);
        hitung = findViewById(R.id.button);
        hasil = findViewById(R.id.textView4);

    }

        public void hitungBilangan(View view) {
            int a1 = Integer.parseInt(bil1.getText().toString());
            int a2 = Integer.parseInt(bil2.getText().toString());
            String hitungBilangan = operasi.getText().toString();

            switch (hitungBilangan) {
                case "+" :
                    int hitung = a1 + a2;
                    hasil.setText(String.valueOf(hitung));
                    break;

                case "-" :
                    int hitung2 = a1 - a2;
                    hasil.setText(String.valueOf(hitung2));
                    break;

                case "*" :
                    int hitung3 = a1 * a2;
                    hasil.setText(String.valueOf(hitung3));
                    break;

                case "/" :
                    int hitung4 = a1 / a2;
                    hasil.setText(String.valueOf(hitung4));
                    break;

                default:
                    hasil.setText("operasi aritmatika tidak sesuai");

            }


        }
}